package cardgame;

public class CardLinkedList {
    private CardNode head;

    public void addCard(String card) {
        CardNode newNode = new CardNode(card);
        if (head == null) {
            head = newNode;
        } else {
            CardNode current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newNode;
        }
    }

    public String drawCard() {
        if (head == null) return null;
        String card = head.card;
        head = head.next;
        return card;
    }

    public boolean isEmpty() {
        return head == null;
    }
}
