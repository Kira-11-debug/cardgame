package cardgame;

public class Deck {

    public static void main(String[] args) {
        String[] SUITS = { "Clubs", "Diamonds", "Hearts", "Spades" };
        String[] RANKS = { "2", "3", "4", "5", "6", "7", "8", "9", "10",
                "Jack", "Queen", "King", "Ace" };

        int n = SUITS.length * RANKS.length;
        String[] deck = new String[n];
        for (int i = 0; i < RANKS.length; i++) {
            for (int j = 0; j < SUITS.length; j++) {
                deck[SUITS.length * i + j] = RANKS[i] + " of " + SUITS[j];
            }
        }

        for (int i = 0; i < n; i++) {
            int r = i + (int) (Math.random() * (n - i));
            String temp = deck[r];
            deck[r] = deck[i];
            deck[i] = temp;
        }

        CardLinkedList player1 = new CardLinkedList();
        CardLinkedList player2 = new CardLinkedList();

        for (int i = 0; i < n; i++) {
            if (i % 2 == 0)
                player1.addCard(deck[i]);
            else
                player2.addCard(deck[i]);
        }

        int player1Score = 0;
        int player2Score = 0;

        while (!player1.isEmpty() && !player2.isEmpty()) {
            String p1Card = player1.drawCard();
            String p2Card = player2.drawCard();

            int p1Val = getCardValue(p1Card);
            int p2Val = getCardValue(p2Card);

            System.out.println("Player 1 draws: " + p1Card);
            System.out.println("Player 2 draws: " + p2Card);

            if (p1Val > p2Val) {
                player1Score++;
                System.out.println("Player 1 wins the round\n");
            } else if (p2Val > p1Val) {
                player2Score++;
                System.out.println("Player 2 wins the round\n");
            } else {
                System.out.println("It's a tie!\n");
            }
        }

        System.out.println("Final Score:");
        System.out.println("Player 1: " + player1Score);
        System.out.println("Player 2: " + player2Score);
        if (player1Score > player2Score)
            System.out.println("Player 1 wins the game!");
        else if (player2Score > player1Score)
            System.out.println("Player 2 wins the game!");
        else
            System.out.println("The game is a tie!");
    }

    public static int getCardValue(String card) {
        String rank = card.split(" ")[0];
        switch (rank) {
            case "2": return 2;
            case "3": return 3;
            case "4": return 4;
            case "5": return 5;
            case "6": return 6;
            case "7": return 7;
            case "8": return 8;
            case "9": return 9;
            case "10": return 10;
            case "Jack": return 11;
            case "Queen": return 12;
            case "King": return 13;
            case "Ace": return 14;
            default: return 0;
        }
    }
}
