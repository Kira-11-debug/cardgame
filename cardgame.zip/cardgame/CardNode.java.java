package cardgame;

public class CardNode {
    String card;
    CardNode next;

    public CardNode(String card) {
        this.card = card;
        this.next = null;
    }
}
