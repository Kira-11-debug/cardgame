 Linked List Card Game 

**Name:** Jaskeerat Kaur  
**Date:** May 14, 2025

## Game Rules:
- 2 players draw cards
- Higher value wins the round
- Score is tracked
- Player with most rounds wins

## Uses Linked List:
- Each player’s deck is a linked list (CardLinkedList)
- Draw card = remove head of the list

## How to Play:
- Run Deck.java
- Game is text-based in the console
